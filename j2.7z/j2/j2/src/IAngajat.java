public interface IAngajat {
    public static final double salariuOrarMinim=15;
    public void setNrOreLucrate(int nrOreLucrate);
    public double salariu();
}
