public class CalculSalarii {

    public static void main(String[] args) {
        Inginer inginer[]=new Inginer[2];
        inginer[0]=new Inginer("Barbulescu","Barbu");
        inginer[1]=new Inginer("Trestie","Tudor");
        Sofer sofer=new Sofer("Repede","Raul");

        IAngajat iAngajat[]=new IAngajat[]{inginer[0],inginer[1],sofer};
        int nrore[]={100,200,250};
        int km=1000;
        for(int i=0;i<iAngajat.length;i++)
        {
            iAngajat[i].setNrOreLucrate(nrore[i]);
        }
        sofer.setKmParcursi(km);
        double salariutotal=0;
        for(IAngajat p:iAngajat)
        {
            salariutotal+=p.salariu();
            System.out.println(p);
        }
        System.out.println("Salariul total "+salariutotal);

    }
}
