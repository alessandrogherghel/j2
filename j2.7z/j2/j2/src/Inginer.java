public class Inginer extends Persoana implements IAngajat {

    public static final double salariuOrarMinim=15;
    int nrOreLucrate;
    final double coeficientSalarial=1.5;


    public Inginer(String nume, String prenume) {
        super(nume, prenume);


    }

    public void setNrOreLucrate(int nrOreLucrate)
    {
            if(nrOreLucrate<=250)
            {
                this.nrOreLucrate=nrOreLucrate;
            }

    }
    public double salariu()
    {
        return salariuOrarMinim*coeficientSalarial*nrOreLucrate;
    }

    @Override
    public String toString() {
        return "Inginer "+super.toString()+" a lucrat "+nrOreLucrate+" ore"+"-salariu="+salariu();
    }
}
