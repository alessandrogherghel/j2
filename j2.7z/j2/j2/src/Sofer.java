public class Sofer extends Persoana implements IAngajat{
    public static final double salariuOrarMinim=15;
    final double coeficientSalarial=1.0;
    int km,nrOreLucrate;

    public Sofer(String nume, String prenume) {
        super(nume, prenume);

    }

    public void setKmParcursi(int km) {
        if(km<=5000)
        {
            this.km=km;
        }
    }

    public void setNrOreLucrate(int nrOreLucrate)
    {
        if(nrOreLucrate<=300)
        {
            this.nrOreLucrate=nrOreLucrate;
        }
    }
    public double salariu()
    {
        return salariuOrarMinim*coeficientSalarial*nrOreLucrate+km*0.1;
    }
    @Override
    public String toString() {
        return "Sofer "+super.toString()+"a lucrat "+nrOreLucrate+" ore"+",a parcurs "+km+" km"+"-salariu="+salariu();
    }
}
