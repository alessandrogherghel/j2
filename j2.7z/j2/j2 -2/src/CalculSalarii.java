public class CalculSalarii {

    public static void main(String[] args) {
        Sofer sofer=new Sofer("Repede","Raul");
        sofer.SetOreLucrate(250,sofer.getNrMaxOreLucrate());
        sofer.setKm_parcursi(1000);
        System.out.println(sofer+"-Salariu="+sofer.salariu());
    }
}
