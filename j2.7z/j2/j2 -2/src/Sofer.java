public class Sofer extends Angajat{
    public static final double salariuOrarMinim=15;
    int kmParcursi,nrMaxOreLucrate=300,kmParcursiMax=5000;

    public Sofer(String nume, String prenume) {
        super(nume, prenume);
    }

    public void setKm_parcursi(int kmParcursi) {
        if(kmParcursi<=this.kmParcursiMax)
        {
            this.kmParcursi = kmParcursi;
        }
    }

    public int getNrMaxOreLucrate() {
        return nrMaxOreLucrate;
    }

    public double salariu()
    {
        return salariuOrarMinim*OreLucrate+kmParcursi*0.1;
    }

    @Override
    public String toString() {
        return super.toString()+",a parcurs "+kmParcursi+" km";
    }
}
