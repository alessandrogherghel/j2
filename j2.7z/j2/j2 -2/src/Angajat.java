public class Angajat extends Persoana{
    protected int OreLucrate;
    public static final double salariuOrarMinim=15;

    public Angajat()
    {

    }

    public Angajat(String nume, String prenume) {
        super(nume, prenume);
    }

    public void SetOreLucrate(int OreLucrate,int NrMaxOreLucrate)
    {
        if(OreLucrate<=NrMaxOreLucrate)
        {
            this.OreLucrate=OreLucrate;
        }
    }
    @Override
    public String toString() {
        return getClass().getName()+" "+super.toString()+" a lucrat "+OreLucrate+" ore";
    }
}
