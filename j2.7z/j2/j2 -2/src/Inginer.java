public class Inginer extends Angajat{

    double coeficientSalarial=1.5;
    int nrMaxOreLucrate=250;


    public Inginer(String nume, String prenume) {
        super(nume, prenume);
    }

    public double getCoeficientSalarial() {
        return coeficientSalarial;
    }

    public int getNrMaxOreLucrate() {
        return nrMaxOreLucrate;
    }

    public double salariu()
    {
        return salariuOrarMinim*coeficientSalarial*OreLucrate;
    }


}
